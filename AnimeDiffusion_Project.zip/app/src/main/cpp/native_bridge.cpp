#include <jni.h>
#include <string>
#include <vector>
#include <android/log.h>

#define TAG "AnimeSD_Native"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

#if __has_include("sd_cpp/stable-diffusion.h")
#include "sd_cpp/stable-diffusion.h"
#define HAS_SD_CPP 1
static sd_ctx_t* g_sd_ctx = nullptr;
#else
#define HAS_SD_CPP 0
#endif

extern "C" JNIEXPORT jboolean JNICALL
Java_com_animediffusion_app_SdNative_loadModel(
    JNIEnv* env, jobject thiz,
    jstring model_path, jstring lora_dir, jboolean vae_tiling) {
#if HAS_SD_CPP
    const char* m_path = env->GetStringUTFChars(model_path, nullptr);
    const char* l_dir = env->GetStringUTFChars(lora_dir, nullptr);

    LOGI("Loading model: %s, LoRA dir: %s, vae_tiling: %d", m_path, l_dir, vae_tiling);

    if (g_sd_ctx != nullptr) {
        free_sd_ctx(g_sd_ctx);
        g_sd_ctx = nullptr;
    }

    g_sd_ctx = new_sd_ctx(
        m_path, "", "", "", l_dir, "", "",
        false, vae_tiling, false, 4,
        SD_TYPE_F16, RNG_STD_DEFAULT, DEFAULT, false, false, false
    );

    env->ReleaseStringUTFChars(model_path, m_path);
    env->ReleaseStringUTFChars(lora_dir, l_dir);

    return g_sd_ctx != nullptr ? JNI_TRUE : JNI_FALSE;
#else
    LOGI("Mock loadModel (sd_cpp header not present at compile time)");
    return JNI_TRUE;
#endif
}

extern "C" JNIEXPORT jbyteArray JNICALL
Java_com_animediffusion_app_SdNative_txt2img(
    JNIEnv* env, jobject thiz,
    jstring prompt, jstring neg_prompt,
    jint width, jint height, jint steps, jfloat cfg, jlong seed) {

#if HAS_SD_CPP
    if (!g_sd_ctx) {
        LOGE("sd_ctx is not loaded");
        return nullptr;
    }

    const char* p = env->GetStringUTFChars(prompt, nullptr);
    const char* np = env->GetStringUTFChars(neg_prompt, nullptr);

    LOGI("Starting txt2img: %dx%d, steps: %d, cfg: %.1f", width, height, steps, cfg);

    sd_image_t* result = txt2img(
        g_sd_ctx, p, np, 1, cfg, width, height,
        EULER_A, steps, seed, 1, nullptr, 0.0f, 0.0f, nullptr
    );

    env->ReleaseStringUTFChars(prompt, p);
    env->ReleaseStringUTFChars(neg_prompt, np);

    if (!result || !result->data) {
        LOGE("Generation failed or returned null");
        return nullptr;
    }

    // result->data is RGB or RGBA
    int size = result->width * result->height * result->channel;
    jbyteArray outArray = env->NewByteArray(size);
    env->SetByteArrayRegion(outArray, 0, size, reinterpret_cast<jbyte*>(result->data));

    free(result->data);
    free(result);

    return outArray;
#else
    LOGI("Mock txt2img generation (placeholder pattern)");
    int size = width * height * 4;
    std::vector<uint8_t> dummy(size);
    for (int y = 0; y < height; y++) {
        for (int x = 0; x < width; x++) {
            int idx = (y * width + x) * 4;
            dummy[idx + 0] = (uint8_t)((x * 255) / width);      // R
            dummy[idx + 1] = (uint8_t)((y * 255) / height);     // G
            dummy[idx + 2] = 200;                               // B
            dummy[idx + 3] = 255;                               // A
        }
    }
    jbyteArray outArray = env->NewByteArray(size);
    env->SetByteArrayRegion(outArray, 0, size, reinterpret_cast<jbyte*>(dummy.data()));
    return outArray;
#endif
}

extern "C" JNIEXPORT void JNICALL
Java_com_animediffusion_app_SdNative_unloadModel(JNIEnv* env, jobject thiz) {
#if HAS_SD_CPP
    if (g_sd_ctx) {
        free_sd_ctx(g_sd_ctx);
        g_sd_ctx = nullptr;
    }
#endif
    LOGI("Model unloaded");
}
