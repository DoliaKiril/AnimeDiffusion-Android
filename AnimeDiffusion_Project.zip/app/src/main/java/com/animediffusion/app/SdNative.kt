package com.animediffusion.app

object SdNative {
    init {
        try {
            System.loadLibrary("sd_bridge")
        } catch (e: UnsatisfiedLinkError) {
            e.printStackTrace()
        }
    }

    external fun loadModel(modelPath: String, loraDir: String, vaeTiling: Boolean): Boolean
    external fun txt2img(prompt: String, negPrompt: String, width: Int, height: Int, steps: Int, cfg: Float, seed: Long): ByteArray?
    external fun unloadModel()
}
