package com.animediffusion.app

object DanbooruTags {
    // Top offline Anime/Gelbooru tags
    val tags = listOf(
        "1girl", "solo", "long_hair", "looking_at_viewer", "smile", "short_hair",
        "open_mouth", "blue_eyes", "blush", "brown_hair", "black_hair", "blonde_hair",
        "red_eyes", "dress", "twintails", "school_uniform", "skirt", "ribbon",
        "white_hair", "green_eyes", "ponytail", "jacket", "shirt", "bow",
        "hair_ornament", "gloves", "closed_eyes", "collarbone", "bare_shoulders",
        "cleavage", "navel", "serafuku", "sailor_collar", "pleated_skirt", "thighhighs",
        "pantyhose", "cat_ears", "animal_ears", "horns", "wings", "halo",
        "masterpiece", "best_quality", "highly_detailed", "cinematic_lighting",
        "anime_aesthetic", "makoto_shinkai", "kyoto_animation", "genshin_impact",
        "night_sky", "cherry_blossoms", "sunlight", "outdoors", "bedroom", "cityscape"
    )

    fun filter(prefix: String): List<String> {
        val clean = prefix.trim().lowercase()
        if (clean.length < 2) return emptyList()
        return tags.filter { it.contains(clean) }.take(6)
    }
}
