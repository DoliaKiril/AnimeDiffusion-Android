package com.animediffusion.app

import android.graphics.Bitmap
import android.os.Bundle
import android.os.Environment
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer

data class LoraItem(
    val name: String,
    val filename: String,
    val previewPath: String?,
    val triggerWords: String,
    var isSelected: Boolean = false,
    var weight: Float = 1.0f
)

data class GeneratedImage(
    val id: String,
    val file: File,
    val bitmap: Bitmap
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                AnimeDiffusionApp()
            }
        }
    }
}

@Composable
fun AnimeDiffusionApp() {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var selectedTab by remember { mutableStateOf(0) }
    val tabTitles = listOf("Генерація", "LoRA", "Параметри", "Галерея", "Налаштування")

    // State
    var prompt by remember { mutableStateOf("1girl, masterpiece, anime style, highly detailed, ") }
    var negPrompt by remember { mutableStateOf("worst quality, low quality, normal quality, blurry, bad anatomy") }
    var selectedRes by remember { mutableStateOf(1600 to 900) } // (width, height)
    var steps by remember { mutableStateOf(24) }
    var cfgScale by remember { mutableStateOf(6.0f) }
    var seed by remember { mutableStateOf(-1L) }
    var clipSkip by remember { mutableStateOf(1) }
    var vaeTiling by remember { mutableStateOf(true) }

    var modelPath by remember { mutableStateOf("/sdcard/models/animagine-xl-3.1.safetensors") }
    var loraDir by remember { mutableStateOf("/sdcard/loras/") }
    var isModelLoaded by remember { mutableStateOf(false) }
    var isGenerating by remember { mutableStateOf(false) }

    var currentPreviewBitmap by remember { mutableStateOf<Bitmap?>(null) }
    val galleryImages = remember { mutableStateListOf<GeneratedImage>() }

    // LoRA List
    val loras = remember {
        mutableStateListOf(
            LoraItem("Ghibli Style", "ghibli_v1.safetensors", null, "studio ghibli style"),
            LoraItem("Detailed Eyes", "anime_eyes_xl.safetensors", null, "beautiful detailed eyes, glowing eyes"),
            LoraItem("Makoto Shinkai", "shinkai_scenery.safetensors", null, "shinkai makoto style, vivid clouds, cinematic light")
        )
    }

    // Help Dialog State
    var activeHelpTitle by remember { mutableStateOf<String?>(null) }
    var activeHelpText by remember { mutableStateOf<String?>(null) }

    Scaffold(
        bottomBar = {
            NavigationBar {
                tabTitles.forEachIndexed { index, title ->
                    NavigationBarItem(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        label = { Text(title, fontSize = 11.sp) },
                        icon = {}
                    )
                }
            }
        }
    ) { padding ->
        Box(modifier = Modifier.padding(padding).fillMaxSize()) {
            when (selectedTab) {
                0 -> GenerationTab(
                    prompt = prompt,
                    onPromptChange = { prompt = it },
                    selectedRes = selectedRes,
                    onResChange = { selectedRes = it },
                    previewBitmap = currentPreviewBitmap,
                    isGenerating = isGenerating,
                    onGenerate = {
                        coroutineScope.launch {
                            isGenerating = true
                            val finalSeed = if (seed < 0) (0..999999999L).random() else seed
                            val rawBytes = withContext(Dispatchers.Default) {
                                SdNative.txt2img(
                                    prompt = prompt,
                                    negPrompt = negPrompt,
                                    width = selectedRes.first,
                                    height = selectedRes.second,
                                    steps = steps,
                                    cfg = cfgScale,
                                    seed = finalSeed
                                )
                            }
                            if (rawBytes != null) {
                                val bmp = Bitmap.createBitmap(selectedRes.first, selectedRes.second, Bitmap.Config.ARGB_8888)
                                bmp.copyPixelsFromBuffer(ByteBuffer.wrap(rawBytes))
                                currentPreviewBitmap = bmp

                                // Save to internal gallery
                                val outDir = File(context.filesDir, "generations")
                                outDir.mkdirs()
                                val outFile = File(outDir, "img_${System.currentTimeMillis()}.png")
                                FileOutputStream(outFile).use { fos -> bmp.compress(Bitmap.CompressFormat.PNG, 100, fos) }
                                galleryImages.add(0, GeneratedImage(outFile.name, outFile, bmp))
                                Toast.makeText(context, "Генерація завершена!", Toast.LENGTH_SHORT).show()
                            } else {
                                Toast.makeText(context, "Помилка генерації. Перевірте пам'ять або модель", Toast.LENGTH_LONG).show()
                            }
                            isGenerating = false
                        }
                    }
                )
                1 -> LoraTab(
                    loras = loras,
                    onToggleLora = { lora, isChecked ->
                        lora.isSelected = isChecked
                        val tag = "<lora:${lora.filename.substringBefore(".")}:${lora.weight}>"
                        if (isChecked) {
                            if (!prompt.contains(tag)) {
                                prompt = if (prompt.endsWith(", ") || prompt.endsWith(",")) "$prompt$tag, ${lora.triggerWords}, " else "$prompt, $tag, ${lora.triggerWords}, "
                            }
                        } else {
                            prompt = prompt.replace(tag, "").replace(lora.triggerWords, "").replace("  ", " ").replace(", ,", ",")
                        }
                    }
                )
                2 -> GenerationSettingsTab(
                    steps = steps,
                    onStepsChange = { steps = it },
                    cfg = cfgScale,
                    onCfgChange = { cfgScale = it },
                    seed = seed,
                    onSeedChange = { seed = it },
                    clipSkip = clipSkip,
                    onClipSkipChange = { clipSkip = it },
                    vaeTiling = vaeTiling,
                    onVaeTilingChange = { vaeTiling = it },
                    onShowHelp = { title, text ->
                        activeHelpTitle = title
                        activeHelpText = text
                    }
                )
                3 -> GalleryTab(
                    images = galleryImages,
                    onDelete = { img ->
                        img.file.delete()
                        galleryImages.remove(img)
                    },
                    onExport = { img ->
                        val picturesDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES)
                        val animeDir = File(picturesDir, "AnimeDiffusion")
                        animeDir.mkdirs()
                        val destFile = File(animeDir, img.file.name)
                        img.file.copyTo(destFile, overwrite = true)
                        Toast.makeText(context, "Збережено в Pictures/AnimeDiffusion!", Toast.LENGTH_SHORT).show()
                    }
                )
                4 -> AppConfigTab(
                    modelPath = modelPath,
                    onModelPathChange = { modelPath = it },
                    loraDir = loraDir,
                    onLoraDirChange = { loraDir = it },
                    isModelLoaded = isModelLoaded,
                    onLoadModel = {
                        coroutineScope.launch {
                            Toast.makeText(context, "Завантаження моделі в Adreno GPU...", Toast.LENGTH_SHORT).show()
                            val success = withContext(Dispatchers.Default) {
                                SdNative.loadModel(modelPath, loraDir, vaeTiling)
                            }
                            isModelLoaded = success
                            Toast.makeText(context, if (success) "Модель успішно завантажена!" else "Помилка завантаження!", Toast.LENGTH_SHORT).show()
                        }
                    }
                )
            }

            // Help Dialog
            if (activeHelpTitle != null && activeHelpText != null) {
                AlertDialog(
                    onDismissRequest = { activeHelpTitle = null },
                    title = { Text(activeHelpTitle!!) },
                    text = { Text(activeHelpText!!) },
                    confirmButton = {
                        TextButton(onClick = { activeHelpTitle = null }) { Text("Зрозуміло") }
                    }
                )
            }
        }
    }
}

@Composable
fun GenerationTab(
    prompt: String,
    onPromptChange: (String) -> Unit,
    selectedRes: Pair<Int, Int>,
    onResChange: (Pair<Int, Int>) -> Unit,
    previewBitmap: Bitmap?,
    isGenerating: Boolean,
    onGenerate: () -> Unit
) {
    val tagSuggestions = remember(prompt) {
        val lastTag = prompt.substringAfterLast(", ").trim()
        DanbooruTags.filter(lastTag)
    }

    Column(modifier = Modifier.fillMaxSize().padding(12.dp)) {
        // Visual Preview Frame matching aspect ratio
        val aspect = selectedRes.first.toFloat() / selectedRes.second.toFloat()
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .clip(RoundedCornerShape(8.dp))
                .background(Color(0xFF1E1E1E))
                .border(1.5.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(8.dp)),
            contentAlignment = Alignment.Center
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize(0.95f)
                    .aspectRatio(aspect, matchHeightConstraintsFirst = false)
                    .border(1.dp, Color.Gray.copy(alpha = 0.5f), RoundedCornerShape(4.dp)),
                contentAlignment = Alignment.Center
            ) {
                if (previewBitmap != null) {
                    Image(
                        bitmap = previewBitmap.asImageBitmap(),
                        contentDescription = "Preview",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Fit
                    )
                } else {
                    Text(
                        "${selectedRes.first} x ${selectedRes.second} (Прев'ю кадру)",
                        color = Color.LightGray,
                        fontSize = 14.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Prompt with autotags
        OutlinedTextField(
            value = prompt,
            onValueChange = onPromptChange,
            label = { Text("Промпт (теги через кому)") },
            modifier = Modifier.fillMaxWidth(),
            maxLines = 3
        )

        if (tagSuggestions.isNotEmpty()) {
            Row(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                tagSuggestions.forEach { tag ->
                    AssistChip(
                        onClick = {
                            val base = prompt.substringBeforeLast(", ")
                            onPromptChange(if (base.isEmpty() || base == prompt) "$tag, " else "$base, $tag, ")
                        },
                        label = { Text(tag, fontSize = 11.sp) },
                        modifier = Modifier.padding(end = 4.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Resolution Presets
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            val presets = listOf(
                "1:1 (1024)" to (1024 to 1024),
                "Портрет" to (832 to 1216),
                "Альбом" to (1216 to 832),
                "1600x900" to (1600 to 900)
            )
            presets.forEach { (label, res) ->
                FilterChip(
                    selected = selectedRes == res,
                    onClick = { onResChange(res) },
                    label = { Text(label, fontSize = 11.sp) }
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        Button(
            onClick = onGenerate,
            modifier = Modifier.fillMaxWidth().height(52.dp),
            enabled = !isGenerating,
            shape = RoundedCornerShape(8.dp)
        ) {
            Text(if (isGenerating) "Генерація на Adreno 830..." else "ГЕНЕРУВАТИ", fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun LoraTab(
    loras: List<LoraItem>,
    onToggleLora: (LoraItem, Boolean) -> Unit
) {
    LazyColumn(modifier = Modifier.fillMaxSize().padding(12.dp)) {
        item {
            Text("Встановлені LoRA", fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text("Виберіть LoRA для автоматичного додавання в промпт", color = Color.Gray, fontSize = 12.sp)
            Spacer(modifier = Modifier.height(8.dp))
        }
        items(loras) { lora ->
            Card(
                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Row(
                    modifier = Modifier.padding(12.dp).fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier.size(54.dp).background(Color.DarkGray, RoundedCornerShape(6.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("LoRA", color = Color.White, fontSize = 12.sp)
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(lora.name, fontWeight = FontWeight.SemiBold)
                        Text("Теги: ${lora.triggerWords}", color = Color.Gray, fontSize = 11.sp, maxLines = 1)
                    }
                    Checkbox(
                        checked = lora.isSelected,
                        onCheckedChange = { onToggleLora(lora, it) }
                    )
                }
            }
        }
    }
}

@Composable
fun GenerationSettingsTab(
    steps: Int,
    onStepsChange: (Int) -> Unit,
    cfg: Float,
    onCfgChange: (Float) -> Unit,
    seed: Long,
    onSeedChange: (Long) -> Unit,
    clipSkip: Int,
    onClipSkipChange: (Int) -> Unit,
    vaeTiling: Boolean,
    onVaeTilingChange: (Boolean) -> Unit,
    onShowHelp: (String, String) -> Unit
) {
    LazyColumn(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        item {
            Text("Параметри генерації", fontWeight = FontWeight.Bold, fontSize = 20.sp)
            Spacer(modifier = Modifier.height(12.dp))
        }

        // Steps
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Steps (Кроки): $steps", fontWeight = FontWeight.Medium)
                IconButton(onClick = {
                    onShowHelp(
                        "Steps (Кількість кроків)",
                        "Визначає, скільки разів нейромережа очищає картинку від шуму.\n\n• Вплив: більше кроків = довша генерація.\n• Рекомендація: 20–28 кроків. Для аніме цього повністю достатньо. Більше 35 не дає помітної різниці."
                    )
                }) { Text("[?]", color = MaterialTheme.colorScheme.primary) }
            }
            Slider(value = steps.toFloat(), onValueChange = { onStepsChange(it.toInt()) }, valueRange = 10f..50f)
            Spacer(modifier = Modifier.height(10.dp))
        }

        // CFG Scale
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("CFG Scale (Слідування промпту): %.1f".format(cfg), fontWeight = FontWeight.Medium)
                IconButton(onClick = {
                    onShowHelp(
                        "CFG Scale",
                        "Наскільки сильно модель змушена слідувати вашим словам.\n\n• Низький (3–5): модель більш креативна, плавні кольори.\n• Оптимальний (5.5–7.0): ідеальний контраст та деталі для аніме.\n• Високий (>8.5): з'являються пересвіти, 'спалені' пікселі та артефакти."
                    )
                }) { Text("[?]", color = MaterialTheme.colorScheme.primary) }
            }
            Slider(value = cfg, onValueChange = onCfgChange, valueRange = 1.0f..15.0f)
            Spacer(modifier = Modifier.height(10.dp))
        }

        // VAE Tiling
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Tiled VAE (Тайлінг VAE)", fontWeight = FontWeight.Medium)
                IconButton(onClick = {
                    onShowHelp(
                        "Tiled VAE",
                        "Розбиває фінальне складання великої картинки (наприклад 1600x900) на шматочки.\n\n• Вплив: запобігає вильотам пам'яті (Out of Memory) на мобільних пристроях! Обов'язково тримати увімкненим для SDXL."
                    )
                }) { Text("[?]", color = MaterialTheme.colorScheme.primary) }
                Spacer(modifier = Modifier.weight(1f))
                Switch(checked = vaeTiling, onCheckedChange = onVaeTilingChange)
            }
            Spacer(modifier = Modifier.height(10.dp))
        }

        // Clip Skip
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Clip Skip: $clipSkip", fontWeight = FontWeight.Medium)
                IconButton(onClick = {
                    onShowHelp(
                        "Clip Skip",
                        "Пропуск останніх шарів текстового енкодера.\n\n• Значення 1: стандарт для більшості SDXL моделей.\n• Значення 2: традиційний стандарт для старих SD 1.5 аніме-моделей (Anything, NAI)."
                    )
                }) { Text("[?]", color = MaterialTheme.colorScheme.primary) }
                Spacer(modifier = Modifier.weight(1f))
                Button(onClick = { onClipSkipChange(if (clipSkip == 1) 2 else 1) }) {
                    Text("$clipSkip")
                }
            }
        }
    }
}

@Composable
fun GalleryTab(
    images: List<GeneratedImage>,
    onDelete: (GeneratedImage) -> Unit,
    onExport: (GeneratedImage) -> Unit
) {
    if (images.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Галерея порожня. Згенеруйте зображення на 1-й вкладці!", color = Color.Gray)
        }
    } else {
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            modifier = Modifier.fillMaxSize().padding(8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(images) { item ->
                Card {
                    Column {
                        Image(
                            bitmap = item.bitmap.asImageBitmap(),
                            contentDescription = null,
                            modifier = Modifier.fillMaxWidth().height(160.dp),
                            contentScale = ContentScale.Crop
                        )
                        Row(modifier = Modifier.fillMaxWidth().padding(4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                            TextButton(onClick = { onExport(item) }) { Text("Зберегти", fontSize = 11.sp) }
                            TextButton(onClick = { onDelete(item) }) { Text("Видалити", color = Color.Red, fontSize = 11.sp) }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AppConfigTab(
    modelPath: String,
    onModelPathChange: (String) -> Unit,
    loraDir: String,
    onLoraDirChange: (String) -> Unit,
    isModelLoaded: Boolean,
    onLoadModel: () -> Unit
) {
    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("Налаштування шляхів", fontWeight = FontWeight.Bold, fontSize = 20.sp)
        Spacer(modifier = Modifier.height(16.dp))

        OutlinedTextField(
            value = modelPath,
            onValueChange = onModelPathChange,
            label = { Text("Шлях до SDXL .safetensors") },
            modifier = Modifier.fillMaxWidth()
        )
        Text("Вкажіть точний шлях до файлу моделі в пам'яті консолі", color = Color.Gray, fontSize = 12.sp)

        Spacer(modifier = Modifier.height(16.dp))

        OutlinedTextField(
            value = loraDir,
            onValueChange = onLoraDirChange,
            label = { Text("Папка з LoRA (.safetensors)") },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(20.dp))

        Button(
            onClick = onLoadModel,
            modifier = Modifier.fillMaxWidth().height(48.dp)
        ) {
            Text(if (isModelLoaded) "Модель готова до роботи" else "Завантажити модель у пам'ять")
        }
    }
}
